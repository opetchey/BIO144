This folder contains the datasets that students will need during the course.

The WaffleDivorce and Milk dataset are from the rethinking package, and saved here as csv files for consistency.